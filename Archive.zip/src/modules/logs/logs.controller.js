import { successResponse, errorResponse } from '../../utils/response.js';
import * as logsService from './logs.service.js';

export async function listLogs(request, reply) {
  try {
    const { tenantId } = request.tenant;
    const { action, entityType, actorUserId, startDate, endDate, limit, offset } = request.query;

    const logs = await logsService.getLogs(tenantId, {
      action,
      entityType,
      actorUserId,
      startDate,
      endDate,
      limit: limit ? parseInt(limit, 10) : 50,
      offset: offset ? parseInt(offset, 10) : 0,
    });

    return reply.send(
      successResponse(logs, { count: logs.length }),
    );
  } catch (error) {
    request.log.error(error);
    throw error;
  }
}

export async function getLog(request, reply) {
  try {
    const { tenantId } = request.tenant;
    const { id } = request.params;

    const log = await logsService.getLogById(tenantId, id);

    if (!log) {
      return reply.code(404).send(
        errorResponse(
          'LOG_NOT_FOUND',
          'Log entry not found',
          {},
          request.id,
        ),
      );
    }

    return reply.send(successResponse(log));
  } catch (error) {
    request.log.error(error);
    throw error;
  }
}

export async function exportLogs(request, reply) {
  try {
    const { tenantId } = request.tenant;
    const { action, entityType, startDate, endDate, format } = request.query;

    const logs = await logsService.getLogsForExport(tenantId, {
      action,
      entityType,
      startDate,
      endDate,
    });

    if (format === 'csv') {
      const csv = convertToCSV(logs);
      reply.type('text/csv');
      reply.header('Content-Disposition', 'attachment; filename="audit-logs.csv"');
      return reply.send(csv);
    }

    // Default to JSON
    reply.type('application/json');
    reply.header('Content-Disposition', 'attachment; filename="audit-logs.json"');
    return reply.send(JSON.stringify(logs, null, 2));
  } catch (error) {
    request.log.error(error);
    throw error;
  }
}

export async function streamLogs(request, reply) {
  try {
    const { tenantId } = request.tenant;
    const { action, entityType, startDate, endDate } = request.query;

    const logs = await logsService.getLogsForExport(tenantId, {
      action,
      entityType,
      startDate,
      endDate,
    });

    reply.type('application/x-ndjson');
    reply.header('Content-Disposition', 'attachment; filename="audit-logs.ndjson"');

    for (const log of logs) {
      reply.write(JSON.stringify(log) + '\n');
    }

    return reply.send();
  } catch (error) {
    request.log.error(error);
    throw error;
  }
}

function convertToCSV(logs) {
  const headers = ['ID', 'Action', 'Entity Type', 'Entity ID', 'Actor Email', 'Created At'];
  const rows = logs.map(log => [
    log.id,
    log.action,
    log.entityType,
    log.entityId,
    log.actor?.email || 'System',
    new Date(log.createdAt).toISOString(),
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
  ].join('\n');

  return csvContent;
}
