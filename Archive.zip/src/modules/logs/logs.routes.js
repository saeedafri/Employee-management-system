import * as logsController from './logs.controller.js';
import { authenticate } from '../../middleware/authenticate.js';

export default async function logsRoutes(fastify) {
  // All log routes require admin access
  fastify.get(
    '/admin/logs',
    { onRequest: [authenticate] },
    async (request, reply) => logsController.listLogs(request, reply),
  );

  fastify.get(
    '/admin/logs/:id',
    { onRequest: [authenticate] },
    async (request, reply) => logsController.getLog(request, reply),
  );

  fastify.get(
    '/admin/logs/export',
    { onRequest: [authenticate] },
    async (request, reply) => logsController.exportLogs(request, reply),
  );

  fastify.get(
    '/admin/logs/stream',
    { onRequest: [authenticate] },
    async (request, reply) => logsController.streamLogs(request, reply),
  );
}
