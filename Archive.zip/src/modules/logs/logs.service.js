import { prisma } from '../../plugins/prisma.js';

export async function getLogs(tenantId, filters = {}) {
  const where = { tenantId };

  if (filters.action) {
    where.action = filters.action;
  }

  if (filters.entityType) {
    where.entityType = filters.entityType;
  }

  if (filters.actorUserId) {
    where.actorUserId = filters.actorUserId;
  }

  if (filters.startDate || filters.endDate) {
    where.createdAt = {};
    if (filters.startDate) {
      where.createdAt.gte = new Date(filters.startDate);
    }
    if (filters.endDate) {
      where.createdAt.lte = new Date(filters.endDate);
    }
  }

  const logs = await prisma.auditLog.findMany({
    where,
    include: {
      actor: {
        select: {
          id: true,
          email: true,
          memberType: true,
        },
      },
      tenant: {
        select: {
          id: true,
          name: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
    take: filters.limit || 50,
    skip: filters.offset || 0,
  });

  return logs;
}

export async function getLogById(tenantId, logId) {
  return prisma.auditLog.findFirst({
    where: {
      id: logId,
      tenantId,
    },
    include: {
      actor: {
        select: {
          id: true,
          email: true,
          memberType: true,
        },
      },
    },
  });
}

export async function getLogsForExport(tenantId, filters = {}) {
  const where = { tenantId };

  if (filters.action) {
    where.action = filters.action;
  }

  if (filters.entityType) {
    where.entityType = filters.entityType;
  }

  if (filters.startDate || filters.endDate) {
    where.createdAt = {};
    if (filters.startDate) {
      where.createdAt.gte = new Date(filters.startDate);
    }
    if (filters.endDate) {
      where.createdAt.lte = new Date(filters.endDate);
    }
  }

  return prisma.auditLog.findMany({
    where,
    include: {
      actor: {
        select: {
          email: true,
          memberType: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  });
}
