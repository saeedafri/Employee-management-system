# System Architecture

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Client (React/Vue)                   │
│           (UI served from separate frontend)             │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP REST API
                         │ (JSON)
┌────────────────────────▼────────────────────────────────┐
│                   Fastify.js Server                      │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Middleware Stack                                   │ │
│  │ ├─ authenticate (JWT validation)                  │ │
│  │ ├─ tenantResolution (X-Tenant-Key header)         │ │
│  │ └─ errorHandler (centralized errors)              │ │
│  └────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Routes & Controllers                               │ │
│  │ ├─ POST /auth/login                                │ │
│  │ ├─ POST /auth/refresh                              │ │
│  │ ├─ GET /admin/logs                                 │ │
│  │ └─ ... (12 endpoints total)                        │ │
│  └────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Services & Repositories                            │ │
│  │ ├─ authService (login, token generation)           │ │
│  │ ├─ logsService (filtering, export)                 │ │
│  │ └─ authRepository (DB queries)                     │ │
│  └────────────────────────────────────────────────────┘ │
└────────┬────────────────────┬──────────────────┬────────┘
         │                    │                  │
      MySQL             Redis           BullMQ Queue
   (database)       (session cache)   (email jobs)
   (23 models)      (JWT token info)
